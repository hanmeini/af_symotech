<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';

$conn = new mysqli(
    getenv('DB_HOST') ?: die("DB_HOST belum diset"),
    getenv('DB_USER') ?: die("DB_USER belum diset"),
    getenv('DB_PASS') ?: die("DB_PASS belum diset"),
    getenv('DB_NAME') ?: die("DB_NAME belum diset")
);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$nik = $_GET['nik'] ?? '';
if (!$nik) {
    echo "<script>alert('NIK tidak ditemukan'); window.location.href='belumjoblist.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no_job = trim($_POST['no_job'] ?? '');
    $no_SIP2MI = trim($_POST['no_SIP2MI'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    $gaji2 = trim($_POST['gaji2'] ?? '');
    $negara = trim($_POST['negara'] ?? '');
    $nama_mitra = trim($_POST['nama_mitra'] ?? '');
    $alamat_mitra = trim($_POST['alamat_mitra'] ?? '');
    $telp_mitra = trim($_POST['telp_mitra'] ?? '');
    $email_mitra = trim($_POST['email_mitra'] ?? '');
    $edit = 'clouse';

    $stmt = $conn->prepare("INSERT INTO sebelum_job 
        (nik, no_job, no_SIP2MI, jabatan, gaji2, negara, nama_mitra, alamat_mitra, telp_mitra, email_mitra, edit) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $nik, $no_job, $no_SIP2MI, $jabatan, $gaji2, $negara, $nama_mitra, $alamat_mitra, $telp_mitra, $email_mitra, $edit);

    if ($stmt->execute()) {
        // Update tanggal_sebelum_job di tabel pendaftaran
        $update = $conn->prepare("UPDATE pendaftaran SET tanggal_sebelum_job = CURDATE() WHERE nik = ?");
        $update->bind_param("s", $nik);
        $update->execute();
        $update->close();

        echo "<script>
            alert('Data job berhasil disimpan');
            window.location.href='detail_pekerja.php?nik=" . urlencode($nik) . "';
        </script>";
    } else {
        echo "<script>
            alert('Gagal menyimpan data');
            window.location.href='belumjoblist.php';
        </script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Data Sebelum Job</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
        .container {
            max-width: 700px;
            background: #fff;
            padding: 20px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; }
        label { display: block; margin-top: 15px; font-weight: bold; }
        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background: #28a745;
            color: white;
            font-weight: bold;
            border: none;
            margin-top: 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #218838;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Form Sebelum Job</h2>
    <form method="post">
        <label>NIK</label>
        <input type="text" name="nik" value="<?= htmlspecialchars($nik) ?>" readonly>

        <label>No Job</label>
        <input type="text" name="no_job" required>

        <label>No SIP2MI</label>
        <input type="text" name="no_SIP2MI" required>

        <label>Jabatan</label>
        <input type="text" name="jabatan" required>

        <label>Gaji</label>
        <input type="text" name="gaji2" required>

        <label>Negara</label>
        <input type="text" name="negara" required>

        <label>Nama Mitra</label>
        <input type="text" name="nama_mitra">

        <label>Alamat Mitra</label>
        <input type="text" name="alamat_mitra" required>

        <label>Telp Mitra</label>
        <input type="text" name="telp_mitra">

        <label>Email Mitra</label>
        <input type="email" name="email_mitra">

        <input type="submit" value="Simpan">
    </form>
</div>
</body>
</html>
<?php $conn->close(); ?>
