<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config.php';

$conn = new mysqli(
    getenv('DB_HOST') ?: die("DB_HOST belum diset"),
    getenv('DB_USER') ?: die("DB_USER belum diset"),
    getenv('DB_PASS') ?: die("DB_PASS belum diset"),
    getenv('DB_NAME') ?: die("DB_NAME belum diset")
);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$nik = $_GET['nik'] ?? '';
if (!$nik) {
    echo "<script>alert('NIK tidak ditemukan'); window.location.href='pasportidlist.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_paspor = trim($_POST['nama_paspor'] ?? '');
    $no_paspor = trim($_POST['no_paspor'] ?? '');
    $tgl_paspor = $_POST['tgl_paspor'] ?? '';
    $tglend_paspor = $_POST['tglend_paspor'] ?? '';
    $penerbit_paspor = trim($_POST['penerbit_paspor'] ?? '');
    $edit = 'clouse';

    $stmt = $conn->prepare("INSERT INTO pembuatan_paspor 
        (nik, nama_paspor, no_paspor, tgl_paspor, tglend_paspor, penerbit_paspor, edit) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $nik, $nama_paspor, $no_paspor, $tgl_paspor, $tglend_paspor, $penerbit_paspor, $edit);

    if ($stmt->execute()) {
        // Update tanggal_pembuatan_pasport di tabel pendaftaran
        $update = $conn->prepare("UPDATE pendaftaran SET tanggal_pembuatan_pasport = CURDATE() WHERE nik = ?");
        $update->bind_param("s", $nik);
        $update->execute();
        $update->close();

        echo "<script>
            alert('Data paspor berhasil disimpan');
            window.location.href='detail_pekerja.php?nik=" . urlencode($nik) . "';
        </script>";
    } else {
        echo "<script>
            alert('Gagal menyimpan data');
            window.location.href='pasportidlist.php';
        </script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Data Pembuatan Paspor</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
        .container {
            max-width: 700px;
            background: #fff;
            padding: 20px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; }
        label { display: block; margin-top: 15px; font-weight: bold; }
        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background: #17a2b8;
            color: white;
            font-weight: bold;
            border: none;
            margin-top: 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #138496;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Form Pembuatan Paspor</h2>
    <form method="post">
        <label>NIK</label>
        <input type="text" name="nik" value="<?= htmlspecialchars($nik) ?>" readonly>

        <label>Nama di Paspor</label>
        <input type="text" name="nama_paspor" required>

        <label>No Paspor</label>
        <input type="text" name="no_paspor" required>

        <label>Tanggal Terbit Paspor</label>
        <input type="date" name="tgl_paspor" required>

        <label>Tanggal Berakhir Paspor</label>
        <input type="date" name="tglend_paspor" required>

        <label>Penerbit Paspor</label>
        <input type="text" name="penerbit_paspor" required>

        <input type="submit" value="Simpan">
    </form>
</div>
</body>
</html>
<?php $conn->close(); ?>
