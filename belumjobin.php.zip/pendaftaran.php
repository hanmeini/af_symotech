<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'config.php';

$conn = new mysqli(
    getenv('DB_HOST') ?: die("DB_HOST belum diset"),
    getenv('DB_USER') ?: die("DB_USER belum diset"),
    getenv('DB_PASS') ?: die("DB_PASS belum diset"),
    getenv('DB_NAME') ?: die("DB_NAME belum diset")
);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$sponsorList = $conn->query("SELECT nik, nama FROM sponsor ORDER BY nama ASC");
$cabangList = $conn->query("SELECT idl, nama_cabang FROM location ORDER BY nama_cabang ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nik     = trim($_POST['nik'] ?? '');
    $cabang  = intval($_POST['cabang'] ?? 0);
    $sponsor = trim($_POST['sponsor'] ?? '');

    // Cek duplikat
    $cek = $conn->prepare("
        SELECT p.nik, l.nama_cabang, s.nama
        FROM pendaftaran p
        LEFT JOIN location l ON p.cabang = l.idl
        LEFT JOIN sponsor s ON p.sponsor = s.nik
        WHERE p.nik = ?
    ");
    $cek->bind_param("s", $nik);
    $cek->execute();
    $cek->store_result();
    if ($cek->num_rows > 0) {
        $cek->bind_result($exist_nik, $exist_cabang, $exist_sponsor);
        $cek->fetch();
        echo "<script>
            alert('NIK sudah terdaftar di \"$exist_cabang\" dengan sponsor \"$exist_sponsor\"');
            window.location.href='home.php';
        </script>";
        exit;
    }
    $cek->close();

    // Data lainnya
    $nama              = trim($_POST['nama'] ?? '');
    $tempat_lahir      = trim($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir     = $_POST['tanggal_lahir'] ?? '';
    $alamat            = trim($_POST['alamat'] ?? '');
    $kelurahan         = trim($_POST['kelurahan'] ?? '');
    $kecamatan         = trim($_POST['kecamatan'] ?? '');
    $kabupanten        = trim($_POST['kabupanten'] ?? '');
    $telp              = trim($_POST['telp'] ?? '');
    $status            = 'aktive';
    $email             = trim($_POST['email'] ?? '');
    $nama_ibu          = trim($_POST['nama_ibu'] ?? '');
    $nama_ayah         = trim($_POST['nama_ayah'] ?? '');
    $alamat_orang_tua  = trim($_POST['alamat_orang_tua'] ?? '');
    $telp_ortu         = trim($_POST['telp_ortu'] ?? '');
    $nama_ahli_waris   = trim($_POST['nama_ahli_waris'] ?? '');
    $hubungan          = trim($_POST['hubungan'] ?? '');
    $alamat_ahli_waris = trim($_POST['alamat_ahli_waris'] ?? '');
    $telp_ahli_waris   = trim($_POST['telp_ahli_waris'] ?? '');
    $email_ahli_waris  = trim($_POST['email_ahli_waris'] ?? '');
    $budget            = intval($_POST['budget'] ?? 0);
    $edit              = 'clouse';
    $tanggal_pendafaran = date('Y-m-d');

    // Upload foto
    $ft = '';
    if (isset($_FILES['ft']) && $_FILES['ft']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($_FILES['ft']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $ft = uniqid('foto_') . '.' . $ext;
            $path = "/home/symotech/af.symotech.id/pekerja/" . $ft;
            move_uploaded_file($_FILES['ft']['tmp_name'], $path);
        } else {
            die("Format file tidak valid. Harus jpg/jpeg/png/gif.");
        }
    } else {
        die("File foto wajib diunggah.");
    }

    // Simpan data
    $stmt = $conn->prepare("INSERT INTO pendaftaran 
        (nik, nama, tempat_lahir, tanggal_lahir, alamat, kelurahan, kecamatan, kabupanten, telp, status, email, ft, 
         nama_ibu, nama_ayah, alamat_orang_tua, telp_ortu, nama_ahli_waris, hubungan, alamat_ahli_waris, 
         telp_ahli_waris, email_ahli_waris, cabang, edit, budget, sponsor, tanggal_pendafaran)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

    $stmt->bind_param(
        "ssssssssssssssssssssssssss",
        $nik, $nama, $tempat_lahir, $tanggal_lahir, $alamat, $kelurahan, $kecamatan, $kabupanten, $telp,
        $status, $email, $ft, $nama_ibu, $nama_ayah, $alamat_orang_tua, $telp_ortu,
        $nama_ahli_waris, $hubungan, $alamat_ahli_waris, $telp_ahli_waris, $email_ahli_waris,
        $cabang, $edit, $budget, $sponsor, $tanggal_pendafaran
    );

    if ($stmt->execute()) {
        echo "<script>
            alert('Data berhasil disimpan');
            window.location.href='detail_pekerja.php?nik=" . urlencode($nik) . "';
        </script>";
    } else {
        echo "<script>alert('Gagal menyimpan data');</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Formulir Pendaftaran</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; }
        .container { max-width: 800px; margin: 30px auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,.1); }
        label { font-weight: bold; margin-top: 10px; display: block; }
        input, textarea, select { width: 100%; padding: 8px; margin-top: 4px; border: 1px solid #ccc; border-radius: 4px; }
        input[type="submit"] { background: #28a745; color: white; border: none; margin-top: 15px; }
        input[type="submit"]:hover { background: #218838; cursor: pointer; }
    </style>
</head>
<body>
<div class="container">
    <h2>Formulir Pendaftaran</h2>
    <form method="post" enctype="multipart/form-data">
        <label>NIK</label>
        <input type="text" name="nik" required>

        <label>Nama</label>
        <input type="text" name="nama" required>

        <label>Tempat Lahir</label>
        <input type="text" name="tempat_lahir" required>

        <label>Tanggal Lahir</label>
        <input type="date" name="tanggal_lahir" required>

        <label>Alamat</label>
        <textarea name="alamat"></textarea>

        <label>Kelurahan</label>
        <input type="text" name="kelurahan" required>

        <label>Kecamatan</label>
        <input type="text" name="kecamatan" required>

        <label>Kabupaten</label>
        <input type="text" name="kabupanten" required>

        <label>Telp</label>
        <input type="text" name="telp">

        <label>Email</label>
        <input type="email" name="email">

        <label>Foto (jpg/png/jpeg/gif)</label>
        <input type="file" name="ft" accept="image/*" required>

        <label>Nama Ibu</label>
        <input type="text" name="nama_ibu">

        <label>Nama Ayah</label>
        <input type="text" name="nama_ayah">

        <label>Alamat Orang Tua</label>
        <input type="text" name="alamat_orang_tua" required>

        <label>Telp Orang Tua</label>
        <input type="text" name="telp_ortu">

        <label>Nama Ahli Waris</label>
        <input type="text" name="nama_ahli_waris">

        <label>Hubungan</label>
        <input type="text" name="hubungan">

        <label>Alamat Ahli Waris</label>
        <input type="text" name="alamat_ahli_waris" required>

        <label>Telp Ahli Waris</label>
        <input type="text" name="telp_ahli_waris">

        <label>Email Ahli Waris</label>
        <input type="email" name="email_ahli_waris">

        <label>Cabang</label>
        <select name="cabang" required>
            <option value="">-- Pilih Cabang --</option>
            <?php while($cb = $cabangList->fetch_assoc()): ?>
                <option value="<?= $cb['idl'] ?>"><?= htmlspecialchars($cb['nama_cabang']) ?></option>
            <?php endwhile; ?>
        </select>

        <label>Budget</label>
        <input type="number" name="budget" required>

        <label>Sponsor (cari NIK atau Nama)</label>
        <select name="sponsor" required>
            <option value="">-- Pilih Sponsor --</option>
            <?php while($sp = $sponsorList->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($sp['nik']) ?>">
                    <?= htmlspecialchars($sp['nik'] . ' - ' . $sp['nama']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <input type="submit" value="Simpan">
    </form>
</div>
</body>
</html>
<?php $conn->close(); ?>
